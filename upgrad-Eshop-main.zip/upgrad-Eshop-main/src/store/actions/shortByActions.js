export const setShortByMode = (mode) => {
   return {
      type: "SET_SHORT_BY_MODE",
      payload: mode
   }
}