Upgrad Movie application project
USE npm install and then npm start
